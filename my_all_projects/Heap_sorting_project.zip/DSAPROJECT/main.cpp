#include<iostream>
using namespace std;


//Node class here
template <class T>
class Node
{
public:
	T data;
	Node<T>* left;
	Node<T>* right;
};


//binary tree class here
template <class T>
class BT
{
	Node<T>* root;
	int count = 0;
	T *ar;
	int i = 0;
public:
	//default constructor of binary tree class
	BT<T>()
	{
		root = nullptr;
		ar = new T[50];
	}


	//Node insertion code here
	void insert(T value)
	{
		Node<T>* n = new Node<T>;
		n->data = value;
		n->left = nullptr;
		n->right = nullptr;

		if (root == nullptr)
		{
			root = n;
			ar[i] = n->data;
			i++;
		}
		else
		{
			Node<T>* temp = root;
			while (true)
			{
				if (temp->left == nullptr)
				{
					temp->left = n;
					ar[i] = n->data;
					i++;
					count += 1;
					break;
				}
				if (temp->right == nullptr)
				{
					temp->right = n;
					ar[i] = n->data;
					i++;
					count += 1;
					break;
				}
				if (count == 8 || count == 9)
				{
					temp = temp->left;
					temp = temp->right;
					if (temp->left == nullptr)
					{
						temp->left = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
					else
					{
						temp->right = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
				}
				if (count == 10 || count == 11)
				{
					temp = temp->right;
					temp = temp->left;
					if (temp->left == nullptr)
					{
						temp->left = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
					else
					{
						temp->right = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
				}
				//for left side nodes
				if (count == 2 || count == 3 || count == 6 || count == 7)
				{
					if (temp->left == nullptr)
					{
						temp->left = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
					if (temp->right == nullptr)
					{
						temp->right = n;
						ar[i] = n->data;
						i++;
						count += 1;
						break;
					}
					else
					{
						temp = temp->left;
					}
				}
				//for right side nodes
				else
				{
					if (temp->right == nullptr)
					{
						if (temp->left == nullptr)
						{
							temp->left = n;
							ar[i] = n->data;
							i++;
							count += 1;
							break;
						}
						else
						{
							temp->right = n;
							ar[i] = n->data;
							i++;
							count += 1;
							break;
						}
					}
					else
					{
						temp = temp->right;
					}
				}
			}
		}
	}


	//swap function
	void Swap(T &a, T &b)
	{
		T temp = a;
		a = b;
		b = temp;
	}

	//min heapify
	void heapify_min(T tree_array[], int size, int i) 
	{
		int large_value = i;
		int left_child = 2 * i + 1;
		int right_child = 2 * i + 2;

		if (left_child < size && tree_array[left_child] > tree_array[large_value])
		{
			large_value = left_child;
		}

		if (right_child < size && tree_array[right_child] > tree_array[large_value])
		{
			large_value = right_child;
		}

		if (large_value != i) 
		{
			Swap(tree_array[i], tree_array[large_value]);
			heapify_min(tree_array, size, large_value);
		}
	}


	//max heapify
	void heapify_max(T tree_array[], int size, int i)
	{
		int small_value = i;
		int left_child = 2 * i + 1;
		int right_child = 2 * i + 2;

		if (left_child < size && tree_array[left_child] < tree_array[small_value])
		{
			small_value = left_child;
		}

		if (right_child < size && tree_array[right_child] < tree_array[small_value])
		{
			small_value = right_child;
		}

		if (small_value != i) 
		{
			Swap(tree_array[i], tree_array[small_value]);
			heapify_max(tree_array, size, small_value);
		}
	}


	//min heapsort function
	void sort_min(T tree_array[], int size)
	{
		for (int i = size / 2 - 1; i >= 0; i--)
		{
			heapify_min(tree_array, size, i);
		}

		for (int i = size - 1; i >= 0; i--) 
		{
			Swap(tree_array[0], tree_array[i]);
			heapify_min(tree_array, i, 0);
		}
	}


	//max heapsort function
	void sort_max(T tree_array[], int size) 
	{
		for (int i = size / 2 - 1; i >= 0; i--)
		{
			heapify_max(tree_array, size, i);
		}

		for (int i = size - 1; i >= 0; i--) 
		{
			Swap(tree_array[0], tree_array[i]);
			heapify_max(tree_array, i, 0);
		}
	}


	//wrapper function for printing array after heap sort
	void printArray(T tree_array[], int size)
	{
		for (int i = 0; i < size; i++)
		{
			cout << tree_array[i] << " ";
		}
	}


	//print wrapper function for min_heap sort
	void printsort_min()
	{
		sort_min(ar, count + 1);
	}


	//print wrapper function for max_heap sort
	void printsort_max()
	{
		sort_max(ar, count + 1);
	}


	//Displaying binary tree values
	void DisplayTree()
	{
		for (int i = 0; i <= count; i++)
		{
			cout << ar[i] << " ";
		}
	}


	//displaying tree After sorting
	void display()
	{
		printArray(ar, count + 1);
	}

	~BT()
	{
		delete[]ar;
	}
};

int main()
{
	BT<double> b;
	b.insert(10.1);
	b.insert(5.5);
	b.insert(7.8);
	b.insert(4.3);
	b.insert(3.9);
	b.insert(15.2);
	b.insert(13.6);

	cout << "Your actual tree is: ";
	b.DisplayTree();
	cout << "\nAfter  MinHeap sorting: ";
	b.printsort_min();
	b.display();
	cout << "\nAfter  MaxHeap sorting: ";
	b.printsort_max();
	b.display();
	cout << endl;
	system("pause");
	return 0;
}