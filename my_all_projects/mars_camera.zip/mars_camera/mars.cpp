#include<iostream>
#include<fstream>
#include<Windows.h>
using namespace std;

void color(int color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

int main()
{
	bool check = false, search = false, first_row = false, second_row = false, third_row = false, start = false, check_t = false;
	ifstream fin;
	int arr[12][12] = { 0 };
	int find[3][3] = { 0 };
	int f = 0, index[2][2], l = 0, k = 0, starting_index = 0, count = 0, add_color_num_start = 0;
	int f_r[10][10] = { 0 }, s_r[10][10] = { 0 }, t_r[10][10] = { 0 };
	fin.open("input.txt");
	ifstream poi;
	ofstream fout;
	fout.open("output.txt");
	poi.open("poi.txt");
	int rowsize = 0, colsize = 0;
	if (fin.is_open())
	{
		fin >> rowsize;
		fin >> colsize;
		while (!fin.eof())
		{
			for (int i = 0; i < rowsize; i++)
			{
				for (int j = 0; j < colsize; j++)
				{
					fin >> arr[i][j];
				}
			}

		}
		for (int i = 0; i < rowsize; i++)
		{
			for (int j = 0; j < colsize; j++)
			{
				cout << arr[i][j] << "  ";
			}
			cout << endl;
		}
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				poi >> find[i][j];
			}
		}
		cout << endl << "-------------------------------" << endl;
		cout << "POI File Data " << endl;
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				cout << find[i][j] << " ";
			}
			cout << endl;
		}
		cout << "-------------------------------" << endl;
		count = 0;
		for (int i = 0; i < rowsize; i++)
		{
			if ((first_row == true) && (second_row == false) && (check_t == true))
			{
				break;
			}
			k = 0;
			for (int j = 0; j < colsize; j++)
			{
				if (first_row == false)
				{
					if (k == 2)
					{
						f_r[1][0] = i;
						f_r[1][1] = j;
						first_row = true;
						second_row = true;
						break;
					}
					if (find[0][k] == arr[i][j])
					{
						if (k == 0) {
							f_r[0][0] = i;
							f_r[0][1] = j;
						}
						k++;
					}
					else
					{
						k = 0;
					}

				}
				if (second_row == true)
				{
					if (k == 2)
					{
						s_r[1][0] = i;
						s_r[1][1] = j;
						first_row = true;
						second_row = false;
						third_row = true;
						break;
					}
					if (find[1][k] == arr[i][j])
					{
						if (k == 0)
						{
							s_r[0][0] = i;
							s_r[0][1] = j;
						}
						count++;
						k++;
					}
					else
					{
						k = 0;
						count = 0;
					}

				}
				if (third_row == true)
				{
					if (k == 2)
					{
						t_r[1][0] = i;
						t_r[1][1] = j;
						first_row = true;
						second_row = false;
						third_row = true;
						check_t = true;
						break;
					}
					if (find[2][k] == arr[i][j])
					{
						if (k == 0)
						{
							t_r[0][0] = i;
							t_r[0][1] = j;
						}
						k++;
					}
					else
					{
						k = 0;
					}
				}
			}
		}
		if (first_row == true)
		{
			if (second_row == false)
			{
				if (third_row == true)
				{
					cout << "Found..." << endl;
					cout << "--------------------------------------" << endl;
					cout << "POI " << endl;
					cout << "--------------------------------------" << endl;
					for (int i = 0; i < rowsize; i++)
					{
						for (int j = 0; j < colsize; j++)
						{
							if ((f_r[0][0] == i) && (f_r[0][1] == j))
							{
								for (int k = 0;k<3;k++)
								{
									color(3);
									cout << "-" << arr[i][j++] << " ";
									fout << "-" << arr[i][j] << " ";
								}
							}
							else if ((s_r[0][0] == i) && (s_r[0][1] == j))
							{
								for (int k = 0;k<3;k++)
								{
									color(3);
									cout << "-" << arr[i][j++] << " ";
									fout << "-" << arr[i][j] << " ";
								}
							}
							else if ((t_r[0][0] == i) && (t_r[0][1] == j))
							{
								for (int k = 0;k<3;k++)
								{
									color(3);
									cout << "-" << arr[i][j++] << " ";
									fout << "-" << arr[i][j] << " ";
								}
							}
							else
							{
								color(7);
								cout << arr[i][j] << " ";
								fout << arr[i][j] << " ";
							}

						}
						cout << endl;
						fout << endl;
					}
				}
				else
				{
					cout << "No Rows Found..." << endl;
				}
			}
			else
			{
				cout << "No Rows Found..." << endl;
			}
		}
		else
		{
			cout << "No Rows Found..." << endl;
		}
	}
	else
	{
		cout << "File not found: " << endl;
	}
	system("pause");
	return 0;
}