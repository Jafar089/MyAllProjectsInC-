#include "Line.h"


//default constructor
Line::Line()
{
	flag = false;
}

//parameterized constructor
Line::Line(int len, char a,bool f):Shape(len,a)
{
	flag = f;
}

//copy constructor
Line::Line(const Line& obj)
{
	int len = obj.getLength();
	this->setLength(len);
	this->setCharacter(obj.getCharacter());
	this->flag = obj.flag;
}

//setter for flag
void Line::setFlag(bool f)
{
	flag = f;
}

//getter for flag
bool Line::getFlag()const
{
	return flag;
}

//read function
void Line::read()
{

}

//display function
void Line::display()
{
	cout << "<Shape: " << getLength() << getCharacter() << "/>" << endl;
	cout << "<Line: " << flag << "/>" << endl;
}

//draw function
void Line::render()
{
	if (flag == true)
	{
		for (int i = 0; i < getLength(); i++)
		{
			cout << getCharacter();
		}
		cout << endl;
	}
	else
	{
		for (int i = 0; i < getLength(); i++)
		{
			cout << getCharacter() << endl;
		}
	}
}


Line Line::operator = (const Line& obj)
{
	int len = obj.getLength();
	this->setLength(len);
	this->setCharacter(obj.getCharacter());
	this->flag = obj.flag;
	return *this;
}


Line Line::operator + (const Line& obj)
{
	Line t;
	int j = this->getLength() + obj.getLength();
	t.setLength(j);
	t.setCharacter(this->getCharacter());
	t.setFlag(this->flag + obj.flag);
	return t;
}


Line Line::operator++(int i)
{
	Line t = *this;
	i = getLength();
	i++;
	this->setLength(i);
	return t;
}

Line Line::operator--(int i)
{
	Line t;
	i = getLength();
	t.setLength(i--);
	return t;
}



Line Line::operator++()
{
	Line t;
	int i = getLength();
	t.setLength(++i);
	return t;
}

Line Line::operator--()
{
	Line t;
	int i = getLength();
	t.setLength(--i);
	return t;
}

bool Line::operator==(const Line & obj)
{
	if (this->getLength() == obj.getLength() && this->getCharacter() == obj.getCharacter() && this->flag == obj.flag)
	{
		return true;
	}
	return false;
}

bool Line::operator!=(const Line & obj)
{
	if (this->getLength() != obj.getLength() || this->getCharacter() != obj.getCharacter() || this->flag != obj.flag)
	{
		return true;
	}
	return false;
}


istream& operator >> (istream& cin, Line& obj)
{
	int i;
	char a;
	cout << "Enter Line Data: " << endl;
	cout << "Enter length and character: ";
	cin >> i;
	cin >> a;
	obj.setLength(i);
	obj.setCharacter(a);
	cout << "Enter 0 if Line is Horizontal or 1: ";
	cin >> obj.flag;
	return cin;
}


ostream& operator<<(ostream& out, const Line& obj)
{
	out << "<Shape: " << obj.getLength() << " " << obj.getCharacter() << "/>" << endl;
	out << "<Line: " << obj.getFlag() << "/>" << endl;
	return out;
}
