#pragma once
#include"Shape.h"


class Line:public Shape
{
	bool flag;
public:
	Line();
	Line(int len, char a,bool f);
	Line(const Line& obj);
	void setFlag(bool f);
	bool getFlag()const;
	void read();
	void display();
	void render();

	Line operator + (const Line& obj);
	Line operator = (const Line& obj);
	Line operator ++ (int);
	Line operator -- (int);
	Line operator ++ ();
	Line operator -- ();
	bool operator == (const Line& obj);
	bool operator!=(const Line& obj);
	friend istream& operator >> (istream& in, Line& obj);
	friend ostream& operator << (ostream& out, const Line& obj);
};

