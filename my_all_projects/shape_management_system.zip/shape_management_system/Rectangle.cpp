#include "Rectangle.h"

//default constructor
Rectangle::Rectangle()
{
	this->width = 0.0;
	this->flag = false;
}

//parameterized constructor
Rectangle::Rectangle(int len, char a, int w, bool f):Shape(len,a)
{
	this->width = w;
	this->flag = f;
}

//copy constructor
Rectangle::Rectangle(const Rectangle& obj)
{
	int len = obj.getLength();
	this->setLength(len);
	this->setCharacter(obj.getCharacter());
	this->width = obj.width;
	this->flag = obj.flag;
}

//setter for width
void Rectangle::setWidth(int w)
{
	this->width = w;
}

//setter for flag
void Rectangle::setFlag(bool f)
{
	this->flag = f;
}

//getter for width
float Rectangle::getWidth()const
{
	return width;
}

//getter for flag
bool Rectangle::getFlag()const
{
	return flag;
}

void Rectangle::read()
{

}

void Rectangle::display()
{
	cout << "<Shape: " << getLength() << getCharacter() << "/>" << endl;
	cout << "<Rectangle: " << width << " " << flag << "/>" << endl;
}

void Rectangle::render()
{
	if (flag == true)
	{
		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < getLength(); j++)
			{
				cout << getCharacter();
			}
			cout << endl;
		}
	}
	else
	{
		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < getLength(); j++)
			{
				if (i == 0 || i == width - 1)
				{
					cout << getCharacter();
				}
				else
				{
					if (j == 0 || j == getLength() - 1)
					{
						cout << getCharacter();
					}
					else
					{
						cout << " ";
					}
				}
			}
			cout << endl;
		}
	}
}

Rectangle Rectangle::operator = (const Rectangle & obj)
{
	int len = obj.getLength();
	char c = obj.getCharacter();
	this->setLength(len);
	this->setCharacter(c);
	this->width = obj.width;
	this->flag = obj.flag;
	return *this;
}

Rectangle Rectangle::operator+(const Rectangle & obj)
{
	Rectangle t;
	int j = this->getLength() + obj.getLength();
	char c = obj.getCharacter();
	t.setLength(j);
	t.setCharacter(c);
	t.width = this->width + obj.width;
	t.flag = this->flag + obj.flag;
	return t;
}

Rectangle Rectangle::operator++(int i)
{
	Rectangle t = *this;
	i = getLength();
	this->setLength(++i);
	this->setWidth(++width);
	return t;
}

Rectangle Rectangle::operator--(int i)
{
	i = getLength();
	this->setLength(i--);
	this->setWidth(width--);
	return *this;
}

Rectangle Rectangle::operator++()
{
	int i = getLength();
	this->setLength(++i);
	this->setWidth(++width);
	return *this;
}

Rectangle Rectangle::operator--()
{
	int i = getLength();
	this->setLength(--i);
	this->setWidth(--width);
	return *this;
}

bool Rectangle::operator==(const Rectangle & obj)
{
	if (this->getLength() == obj.getLength())
	{
		return true;
	}
	return false;
}

bool Rectangle::operator!=(const Rectangle & obj)
{
	if (this->getLength() != obj.getLength())
	{
		return true;
	}
	return false;
}

istream & operator >> (istream & cin, Rectangle & obj)
{
	int i;char a;
	cout << "Enter Rectangle Data: " << endl;
	cout << "Enter length and character: ";
	cin >> i;
	cin >> a;
	obj.setLength(i);
	obj.setCharacter(a);
	cout << "Enter width: ";
	cin >> obj.width;
	cout << "Enter 1 for shadded and 0 for not shadded: ";
	cin >> obj.flag;
	return cin;
}

ostream & operator<<(ostream & cout, const Rectangle & obj)
{
	cout << "<Shape: " << obj.getLength() << " " << obj.getCharacter() << "/>" << endl;
	cout << "<Rectangle: " << obj.getWidth() << " " << obj.getFlag() << " />" << endl;
	return cout;
}
