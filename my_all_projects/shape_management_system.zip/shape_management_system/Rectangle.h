#pragma once
#include"Shape.h"


class Rectangle:public Shape
{
	float width;
	bool flag;
public:
	Rectangle();
	Rectangle(int len, char a, int w,bool f);
	Rectangle(const Rectangle& obj);
	void setWidth(int w);
	void setFlag(bool f);
	float getWidth()const;
	bool getFlag()const;
	void read();
	void display();
	void render();
	Rectangle operator = (const Rectangle& obj);
	Rectangle operator + (const Rectangle& obj);
	Rectangle operator ++ (int);
	Rectangle operator -- (int);
	Rectangle operator ++ ();
	Rectangle operator -- ();
	bool operator == (const Rectangle& obj);
	bool operator != (const Rectangle& obj);
	friend istream& operator >> (istream& cin, Rectangle& obj);
	friend ostream& operator << (ostream& cout, const Rectangle& obj);
};

