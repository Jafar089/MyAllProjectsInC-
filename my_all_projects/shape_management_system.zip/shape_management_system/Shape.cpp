#include "Shape.h"


//default constructor
Shape::Shape()
{
	this->length = 0;
	this->s = '\0';
}

//parameterized constructor
Shape::Shape(int len, char a)
{
	this->length = len;
	this->s = a;
}

//copy constructor
Shape::Shape(const Shape& obj)
{
	this->length = obj.length;
	this->s = obj.s;
}

//setter for length
void Shape::setLength(int len)
{
	this->length = len;
}

//setter for character
void Shape::setCharacter(char a)
{
	this->s = a;
}

//getter for length
int Shape::getLength()const
{
	return length;
}

//getter for character
char Shape::getCharacter()const
{
	return s;
}


void Shape::operator = (Shape& obj)
{
	this->length = obj.length;
	this->s = obj.s;
}
//
//
//void Shape::operator + (const Shape& obj)
//{
//	this->length = this->length + obj.length;
//	this->s = this->s + obj.s;
//}

//bool Shape::operator == (const Shape& obj)
//{
//	return false;
//}
//
//bool Shape::operator != (const Shape& obj)
//{
//	return false;
//}



//insertion operator
istream& operator>>(istream& cin, Shape& obj)
{
	cout << "Enter Shape Data :" << endl;
	cout << "Enter length and character: ";
	cin >> obj.length;
	cin >> obj.s;
	return cin;
}

//extraction operator
ostream& operator<<(ostream& out, const Shape& obj)
{
	out << obj.length;
	out << obj.s;
	return out;
}