#pragma once
#include<iostream>
using namespace std;

class Shape
{
	int length;
	char s;
public:
	Shape();
	Shape(int len, char a);
	Shape(const Shape &obj);
	void setLength(int len);
	void setCharacter(char a);
	int getLength()const;
	char getCharacter()const;
	virtual void read() = 0;
	virtual void display() = 0;
	virtual void render() = 0;

	//void operator + (const Shape& obj);
	void operator = (Shape& obj);
	//bool operator == (const Shape& obj);
	//bool operator != (const Shape& obj);

	friend ostream& operator << (ostream& out, const Shape& obj);
	friend istream& operator >> (istream& cin, Shape& obj);
};

