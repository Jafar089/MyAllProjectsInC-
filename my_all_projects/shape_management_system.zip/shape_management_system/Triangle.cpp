#include "Triangle.h"

Triangle::Triangle()
{
    this->height = 0;
    this->flag = false;
}

Triangle::Triangle(int len, char a, int h, bool f):Shape(len,a)
{
    this->height = h;
    this->flag = f;
}

Triangle::Triangle(const Triangle& obj)
{
	int len = obj.getLength();
	this->setLength(len);
	this->setCharacter(obj.getCharacter());
    this->height = obj.height;
    this->flag = obj.flag;
}

void Triangle::setHeight(int h)
{
    this->height = h;
}

void Triangle::setFlag(bool f)
{
    this->flag = f;
}

int Triangle::getHeight()const
{
    return height;
}

bool Triangle::getFlag()const
{
    return flag;
}

void Triangle::read()
{
}

void Triangle::display()
{
    cout << "<Shape: " << getLength() << getCharacter() << "/>" << endl;
    cout << "<Triangle: " << height << " " << flag << "/>" << endl;
}

void Triangle::render()
{
    if (flag == true)
    {

        for (int i = 1, k = 0; i <= height; ++i, k = 0)
        {
            for (int space = 1; space <= height - i; ++space)
            {
                cout << "  ";
            }

            while (k != 2 * i - 1)
            {
                cout << getCharacter()<<" ";
                ++k;
            }
            cout << endl;
        }
    }
    else
    {
        for (int i = height; i >= 1; --i)
        {
            for (int j = 1; j <= i; ++j)
            {
                cout << getCharacter() << " ";
            }
            cout << endl;
        }
    }
}


Triangle Triangle::operator=(const Triangle & obj)
{
	int len = obj.getLength();
	char c = obj.getCharacter();
	this->setLength(len);
	this->setCharacter(c);
	this->height = obj.height;
	this->flag = obj.flag;
	return *this;
}

Triangle Triangle::operator+(const Triangle & obj)
{
	Triangle t;
	int j = this->getLength() + obj.getLength();
	char c = obj.getCharacter();
	t.setLength(j);
	t.setCharacter(c);
	t.height = this->height + obj.height;
	return t;
}

Triangle Triangle::operator++(int i)
{
	Triangle t = *this;
	i = getLength();
	this->setLength(++i);
	this->setHeight(++height);
	this->setFlag(++flag);
	return t;
}

Triangle Triangle::operator--(int i)
{
	Triangle t;
	i = getLength();
	t.setLength(i--);
	return t;
}

Triangle Triangle::operator++()
{
	int i = getLength();
	this->setLength(++i);
	return *this;
}

Triangle Triangle::operator--()
{
	int i = getLength();
	this->setLength(--i);
	this->setHeight(--height);
	return *this;
}

bool Triangle::operator==(const Triangle & obj)
{
	if (this->getLength() == obj.getLength())
	{
		return true;
	}
	return false;
}

bool Triangle::operator!=(const Triangle & obj)
{
	if (this->getLength() != obj.getLength())
	{
		return true;
	}
	return false;
}

istream & operator >> (istream & cin, Triangle & obj)
{
	int i;char a;
	cout << "Enter Triangle Data: " << endl;
	cout << "Enter length and character: ";
	cin >> i;
	cin >> a;
	obj.setLength(i);
	obj.setCharacter(a);
	cout << "Enter height: ";
	cin >> obj.height;
	cout << "Enter 1 for upsided and 0 for downsided: ";
	cin >> obj.flag;
	return cin;
}

ostream & operator<<(ostream & cout, const Triangle & obj)
{
	cout << "<Shape: " << obj.getLength() << " " << obj.getCharacter() << "/>" << endl;
	cout << "<Triangle: " << obj.getHeight() << " " << obj.getFlag() << " />" << endl;
	return cout;
}
