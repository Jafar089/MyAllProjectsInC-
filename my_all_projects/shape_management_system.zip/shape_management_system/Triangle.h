#pragma once
#include"Shape.h"

class Triangle:public Shape
{
	int height;
	bool flag;
public:
	Triangle();
	Triangle(int len, char a, int h, bool f);
	Triangle(const Triangle& obj);
	void setHeight(int h);
	void setFlag(bool f);
	int getHeight()const;
	bool getFlag()const;
	void read();
	void display();
	void render();
	Triangle operator = (const Triangle& obj);
	Triangle operator + (const Triangle& obj);
	Triangle operator ++ (int);
	Triangle operator -- (int);
	Triangle operator ++ ();
	Triangle operator -- ();
	bool operator == (const Triangle& obj);
	bool operator != (const Triangle& obj);
	friend istream& operator >> (istream& cin, Triangle& obj);
	friend ostream& operator << (ostream& cout, const Triangle& obj);
};

