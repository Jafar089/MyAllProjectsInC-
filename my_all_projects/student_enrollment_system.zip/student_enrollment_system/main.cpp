#include <iostream>
#include<fstream>
using namespace std;


//input funtion
void input(int* roll, float* mc, float* mm, float* percentage, int& rc)
{
	int x = 0;
	float perc = 0;
	cout << "Enter Roll number of Student " << rc + 1 << " : ";
	cin >> roll[rc];
	cout << "Enter marks of Computer science student " << rc + 1 << " with in 100 : ";
	cin >> mc[rc];
	while (mc[rc] > 100 || mc[rc] < 0)
	{
		cout << "plz enter marks of student " << rc + 1 << " less than 100 : ";
		cin >> mc[rc];
	}
	cout << "Enter marks of math student " << rc + 1 << " with in 100 : ";
	cin >> mm[rc];
	while (mm[rc] > 100 || mm[rc] < 0)
	{
		cout << "Plz enter marks of student " << rc + 1 << " less 100 : ";
		cin >> mm[rc];
	}
	percentage[rc] = ((mc[rc] + mm[rc]) / 2.0);
	rc++;
}



//display function for displaying record of students
void display(int* roll, float* mc, float* mm, float* percentage, int size)
{
	cout << "================================" << endl;
	cout << "Student Record are show below" << endl;
	cout << "================================" << endl;
	for (int y = 1; y <= size - 1; y++)
	{
		cout << "Roll number of Student " << y << " is: " << roll[y - 1] << endl;
		cout << "Marks of Computer science of student " << y << " with in 100 : " << mc[y - 1] << endl;
		cout << "Marks of Math of student " << y << " with in 100 : " << mm[y - 1] << endl;
		cout << "Percentage of student " << y << " : " << percentage[y - 1] << endl;
		cout << "Percentage: " << percentage[y - 1] << " %" << endl;
		if (percentage[y - 1] >= 91 && percentage[y - 1] <= 100)
		{
			cout << "A grade" << endl;
		}
		else if (percentage[y - 1] <= 90 && percentage[y - 1] >= 75)
		{
			cout << "B grade" << endl;
		}
		else if (percentage[y - 1] >= 60 && percentage[y - 1] < 75)
		{
			cout << "C grade" << endl;
		}
		else if (percentage[y - 1] >= 50 && percentage[y - 1] < 60)
		{
			cout << "D grade" << endl;
		}
		else
		{
			cout << "Fail" << endl;;
		}
	}
}



//Performing 7 operations here 
void menu(int* roll, float* mc, float* mm, float* percentage, int& rc, char& choice)
{
	int z, A, x;
	int loc = -1;
	cout << "\n\n\nPress 1 to update Roll Number of a particular Student." << endl;
	cout << "Press 2 to update marks of a particular student for CS" << endl;
	cout << "Press 3 to update marks of CS for all students who are already enrolled." << endl;
	cout << "Press 4 to update marks for Mathematics." << endl;
	cout << "Press 5 to update marks of Mathematics for all students who are already enrolled." << endl;
	cout << "Press 6 to sort the data on the basis of generated percentages" << endl;
	cout << "press 7 to delete the record of particular student " << endl;
	cout << "press 8 to exit..!" << endl;
	cin >> x;


	if (x == 1)
	{
		cout << "Roll numbers before update :" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << roll[i] << " ";
		}
		cout << "\nEnter student roll no to update..!" << endl;
		cin >> z;
		cout << "Enter new roll no: " << endl;
		cin >> A;
		for (int j = 0; j < rc - 1; ++j)
		{
			if (roll[j] == z)
			{
				loc = 0;
				roll[j] = A;
			}
		}
		if (loc == -1)
		{
			cout << "Value not found" << endl;
		}
		else
		{
			cout << "Rollno of students after update" << endl;
			for (int j = 0; j < rc - 1; ++j)
			{
				cout << roll[j] << " ";
			}
			cout << endl;
		}
	}

	else if (x == 2)
	{
		cout << "Marks of student before update:" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << mc[i] << " ";
		}
		cout << "\nEnter student roll no to update marks of computer science..!" << endl;
		cin >> z;
		cout << "Enter number to update marks of particular student :" << endl;
		cin >> A;
		for (int i = 0; i < rc - 1; ++i)
		{
			if (roll[i] == z)
			{
				loc = 0;
				mc[i] = A;
			}
		}
		if (loc == -1)
		{
			cout << "You number is not found" << endl;
		}
		else
		{
			cout << "marks of cs after update :" << endl;
			for (int i = 0; i < rc - 1; ++i)
			{
				cout << mc[i] << " ";
			}
		}
	}

	else if (x == 3)
	{
		cout << "Marks of student before update:" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << mc[i] << " ";
		}

		cout << "\nPlz enter new marks for cs students: " << endl;

		for (int i = 0; i < rc - 1; i++)
		{
			cout << "Enter student " << i + 1 << " marks: ";
			cin >> mc[i];
		}

		cout << "\nMarks of student after update:" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << mc[i] << " ";
		}
	}

	else if (x == 4)
	{
		cout << "Marks of math students before update" << endl;
		for (int i = 0; i < rc - 1; i++)
		{
			cout << mm[i] << " ";
		}
		cout << "\nEnter student roll no to update marks of math: " << endl;
		cin >> z;
		cout << "Enter marks you want to replace with previous" << endl;
		cin >> A;
		for (int i = 0; i < rc - 1; i++)
		{
			if (roll[i] == z)
			{
				loc = 0;
				mm[i] = A;
			}
		}
		if (loc == -1)
		{
			cout << "your value is not found :" << endl;
		}
		else
		{
			cout << "math numbers after updation..!" << endl;
			for (int i = 0; i < rc - 1; i++)
			{
				cout << mm[i] << " ";
			}
		}
	}

	else if (x == 5)
	{
		cout << "Marks of student before update:" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << mm[i] << " ";
		}

		cout << "\nPlz enter new marks for cs students: " << endl;

		for (int i = 0; i < rc - 1; i++)
		{
			cout << "Enter student " << i + 1 << " marks: ";
			cin >> mm[i];
		}

		cout << "\nMarks of student after update:" << endl;
		for (int i = 0; i < rc - 1; ++i)
		{
			cout << mm[i] << " ";
		}
	}

	else if (x == 6)
	{
		for (int i = 0; i < rc - 1; i++)
		{
			for (int j = i + 1; j < rc - 1; j++)
			{
				if (percentage[j] < percentage[i])
				{
					int temp = percentage[i];
					int temp1 = roll[i];
					int temp2 = mc[i];
					int temp3 = mm[i];
					roll[i] = roll[j];
					mc[i] = mc[j];
					mm[i] = mm[j];
					percentage[i] = percentage[j];
					percentage[j] = temp;
					roll[j] = temp1;
					mc[j] = temp2;
					mm[j] = temp3;
				}
			}
		}
		display(roll, mc, mm, percentage, rc);
	}

	else if (x == 7)
	{
		cout << "Enter roll number of the student to delete his/her record..!" << endl;
		cin >> z;
		for (int i = 0; i < rc - 1; ++i)
		{
			if (roll[i] == z)
			{
				loc = 0;
			}
		}
		if (loc == -1)
		{
			cout << "You number is not found" << endl;
		}
		else
		{
			mc[z - 1] = 0;
			mm[z - 1] = 0;
			roll[z - 1] = 0;
			percentage[z - 1] = 0;
			cout << "\n record is deleted..!" << endl;
			cout << "After deleting your records are..!\n" << endl;
			for (int y = 1; y <= rc - 1; y++)
			{
				cout << "Roll number of Student " << y << " is: " << roll[y - 1] << endl;
				cout << "Marks of Computer science of student " << y << " with in 100 : " << mc[y - 1] << endl;
				cout << "Marks of Math of student " << y << " with in 100 : " << mm[y - 1] << endl;
			}
		}
	}

	else if (x == 8)
	{
		choice = 'n';
		return;
	}
}



//function to draw table of student information
void WriteInFile(int* roll, float* mc, float* mm, float* percentage, int size)
{
	ofstream fout;
	fout.open("output.txt");
	if (fout.is_open())
	{
		fout << "\t\t\t\t\tStudent Enrollment Table" << endl;
		fout << "---------------------------------------------------------------------------------------------" << endl;
		fout << "Roll No\t\tComputer Science\t\tMath\t\tPercentage\t\tGrade" << endl;
		for (int y = 0; y < size - 1; y++)
		{
			fout << roll[y] << "\t\t\t" << mc[y] << "\t\t\t" << mm[y] << "  \t\t  " << percentage[y];
			if (percentage[y] >= 91 && percentage[y] <= 100)
			{
				fout << "\t\t\tA" << endl;
			}
			else if (percentage[y] <= 90 && percentage[y] >= 75)
			{
				fout << "\t\t\tB" << endl;
			}
			else if (percentage[y] >= 60 && percentage[y] < 75)
			{
				fout << "\t\t\tC" << endl;
			}
			else if (percentage[y] >= 50 && percentage[y] < 60)
			{
				fout << "\t\t\tD" << endl;
			}
			else
			{
				fout << "\t\t\tF" << endl;;
			}
		}
		fout << "---------------------------------------------------------------------------------------------" << endl;
		fout << "\t\t\t\t\tTHE END" << endl;
		fout << "---------------------------------------------------------------------------------------------" << endl;

	}
	else
	{
		cout << "File not open..!" << endl;
	}
}


//delete dynamic arrays beacause of memory leakage
void DeleteDynamicArrays(int* roll, float* mc, float* mm, float* percentage)
{
	delete[]roll;
	delete[]mc;
	delete[]mm;
	delete[]percentage;
}


//main here
int main()
{
	const int size = 25;
	int* roll = new int[size];
	float* mc = new float[size];
	float* mm = new float[size];
	float* percentage = new float[size];
	int rc = 0;
	char choice = 'y';
	cout << "Welcome to the admin panel..!" << endl;
	cout << "Enter Roll number and data to enroll students..!" << endl;
	while (choice != 'n')
	{
		input(roll, mc, mm, percentage, rc);
		cout << "Would you like to perform other calculations?(Y/N)" << endl;
		cin >> choice;
	}
	rc++;
	while (choice != 'y')
	{
		cout << "\nDo you want to perform any of the following task: " << endl;
		cout << "Press y/Y for yes: " << endl;
		cout << "Press n/N for no: " << endl;
		cout << " Enter your choice: " << endl;
		cin >> choice;
		if (choice == 'N' || choice == 'n')
		{
			display(roll, mc, mm, percentage, rc);
			if (choice == 'N' || choice == 'n')
			{
				choice = 'y';
			}
		}
	}

	while (choice != 'n' && choice != 'N')
	{
		menu(roll, mc, mm, percentage, rc, choice);
	}

	WriteInFile(roll, mc, mm, percentage, rc);
	DeleteDynamicArrays(roll, mc, mm, percentage);

	system("pause");
	return 0;
}