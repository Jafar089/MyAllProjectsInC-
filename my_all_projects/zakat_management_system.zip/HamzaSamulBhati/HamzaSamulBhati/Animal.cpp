#include "Animal.h"

float Animal::process()
{
	int aa;
	int q;
	float c = 0.0;
	cout << "1: Camel" << endl;
	cout << "2: Cow" << endl;
	cout << "3: Goat" << endl;
	cout << "Animal Type: "; cin >> aa;
	cout << "The Quantity: "; cin >> q;

	if (aa == 1)
	{
		if (q > 5)
		{
			while (q > 0)
			{
				q = q - 5;
				c++;
			}
		}
		cout<<"Your Zakat are Goats\n";
		return c;
	}
	else if (aa == 2)
	{
		if (q > 40)
		{
			while (q > 0)
			{
				q = q - 40;
				c = c + 2;
			}
		}
		cout<<"Your Zakat are Goats\n";
		return c;
	}
	else if (aa == 3)
	{
		if (q >= 40 || q <= 120)
		{
			c = 1;
			cout << "Give One She-Goat" << endl;
			return c;
		}
		else if (q > 120 || q <= 200)
		{
			c = 2;
			cout << "Give Two She-Goat" << endl;
			return c;
		}
		else if (q > 200 || q <= 300)
		{
			c = 3;
			cout << "Give Three She-Goat" << endl;
			return c;
		}
		else if (q > 300)
		{
			while (q > 300)
			{
				q = q - 100;
				c = c + 1;
			}
			cout << "Give following She-Goat" << endl;
			return c;
		}
	}
}
