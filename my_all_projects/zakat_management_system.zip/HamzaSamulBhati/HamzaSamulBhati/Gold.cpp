#include "Gold.h"

float Gold::process()
{
	float b=0.0;
	float tola;
	cout << "Enter the Tola: "; cin >> tola;
	if (tola >= 7)
	{
		cout << "Enter Current Price: "; cin >> b;
		return (b / 100)*2.5;
	}
	else
	{
		cout << "Not Eligible for Zakat" << endl;
		return 0;
	}
}