#pragma once

#include"iostream"
using namespace std;
class Money
{
public:
	float process();
};

