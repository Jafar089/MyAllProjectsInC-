#include "Other.h"

float Other::process()
{
	float b = 0.0;
	cout << "Enter the price: "; cin >> b;
	return (b / 100)*2.5;
}
