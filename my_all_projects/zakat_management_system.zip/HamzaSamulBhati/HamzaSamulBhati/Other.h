#pragma once
#include"iostream"
using namespace std;
class Other
{
public:
	float process();
};

