#include "Sliver.h"

float Sliver::process()
{
	float b;
	float tola;
	cout << "Enter the Tola: "; cin >> tola;
	if (tola >= 52.5)
	{
		cout << "Enter Current Price: "; cin >> b;
		return (b / 100)*2.5;
	}
	else
	{
		cout << "Not Eligible for Zakat" << endl;
		return 0;
	}
}