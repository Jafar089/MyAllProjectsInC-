#pragma once
#include"iostream"
using namespace std;
class Sliver
{
public:
	float process();
};

