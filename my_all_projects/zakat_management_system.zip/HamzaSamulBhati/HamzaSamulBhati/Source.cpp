#include "Zakat.h"
#include<fstream>


int main()
{
	const int size = 25;
	int type[25];
	int id[size];
	char name[size][size];
	float price[size];
	ofstream fout;
	fout.open("output.txt");
	int index = 0;
	char c='y';
	cout << "  o------------  Welcome to Zakat System  -----------o" << endl;
	Zakat ss;
	int counter = 0;
	int countar[size];
	int records = 0,i=0;
	while (c != 'N' && c != 'n')
	{
		if (c == 'y' || c == 'Y')
		{
			cout << "o---------- Plz register yourself in zakat database ---------o" << endl;;
			cout << "Enter your name: ";
			cin.getline(name[index], size);
			int len = strlen(name[index]);
			while (c != 'N' && c != 'n')
			{
				if (counter > 0)
				{
					for (int i = 0; i < len; i++)
					{
						name[index][i] = name[records][i];
					}
					name[index][len] = '\0';
				}
				cout << "1: Money" << endl;
				cout << "2: Other" << endl;
				cout << "3: Gold" << endl;
				cout << "4: Animal" << endl;
				cout << "5: Silver" << endl;
				cout << "6: Property" << endl;
				cout << "Enter the Type: "; cin >> type[index];
				ss.setType(type[index]);
				price[index] = ss.process();
				cout << "Your Payable Zakat: " << price[index] << endl;
				index++;
				counter++;
				cout << "kya ap nay or zakat deni hay kisi or cheez ki ? y/y for yes n/N for no" << endl;
				cin >> c;
			}
			cout << "\nWould you like to enter another person? press y/Y for yes n/N for no..!" << endl;
			cin >> c;
			cin.ignore();
			records++;
			counter = 0;
		}
		else
		{
			c = 'n';
		}
	}

	cout << "\n\nPress Y/y for printing data and N/n for termination..!" << endl;
	cin >> c;
	if (c == 'Y' || c == 'y')
	{
		cout << "\no---------------------------------WELCOME TO ZAKAT DATABASE------------------------------------o\n" << endl;
		cout << "NAME\t\t\tZAKAT TYPE\t\t\tZAKAT DONATION" << endl;
		for (int i = 0; i < index; i++)
		{
			cout <<name[i] << "\t\t\t  " << type[i] << "\t\t\t\t" << price[i] << endl;
		}
	}
	else
	{
		cout << "Thank you for comming in zakat center" << endl;
		cout << "Allah nigih baan." << endl;
	}

	fout << "o-------------------------------------WELCOME TO ZAKAT DATABASE----------------------------------------o" << endl;
	fout << "NAME\t\t\tZAKAT TYPE\t\t\tZAKAT DONATION" << endl;

	for (int i = 0; i < index; i++)
	{
		fout << name[i] << "\t\t\t  " << type[i]<<"\t\t\t\t" << price[i] << endl;
	}

	return 0;
}