#include "Zakat.h"
Zakat::Zakat()
{
	this->type = 0;
	this->percent = 0.0;
}
//Constructor
Zakat::Zakat(int aa)
{
	this->type = aa;
	this->percent = 0.0;
}

void Zakat::setType(int aa)
{
	this->type = aa;
	this->percent = 0.0;
}

float Zakat::process()
{
	bool bb = false;
	cout << "Is One Year Complete for this Product(1->Yes/0->No)" << endl; cin >> bb;
	if (bb)
	{
		if (this->type == 1)
		{
			Money ok;
			return ok.process();
		}
		else if (this->type == 2)
		{
			Other ok;
			return ok.process();
		}
		else if (this->type == 3)
		{
			Gold ok;
			return ok.process();
		}
		else if (this->type == 4)
		{
			Animal ok;
			return ok.process();
		}
		else if (this->type == 5)
		{
			Sliver ok;
			return ok.process();
		}
		else if (this->type == 6)
		{
			proparty ok;
			return ok.process();
		}

	}
	return 0;
}
