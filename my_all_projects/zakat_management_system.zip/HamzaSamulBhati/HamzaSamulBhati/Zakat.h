#pragma once
#include"iostream"
using namespace std;
#include "Animal.h"
#include "Gold.h"
#include "Money.h"
#include "Other.h"
#include "proparty.h"
#include "Sliver.h"
class Zakat
{
public:
	Zakat();
	Zakat(int aa);
	void setType(int aa);
	float process();
private:
	float percent;
	int type;
};
