#include "proparty.h"

float proparty::process()
{
	float b;
	cout << "Enter Current Price: "; cin >> b;
	return (b / 100)*2.5;
}