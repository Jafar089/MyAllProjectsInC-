#pragma once
#include"iostream"
using namespace std;
class proparty
{
public:
	float process();
};